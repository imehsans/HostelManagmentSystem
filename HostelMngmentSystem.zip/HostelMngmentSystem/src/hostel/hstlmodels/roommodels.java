package hostel.hstlmodels;

import java.util.Vector;

public class roommodels {

	int rmflag,rmflrnum,rm_id,rmtotbd;////////declarations
	String rmblknam,rmstat,rmnum;
	Vector<Object>temp;
	
	
	
	
	public Vector<Object> getTemp() {
		return temp;
	}
	public void setTemp(Vector<Object> temp) {
		this.temp = temp;
	}
	public int getRmflag() {
		return rmflag;
	}
	public void setRmflag(int rmflag) {
		this.rmflag = rmflag;
	}
	public int getRmflrnum() {
		return rmflrnum;
	}
	public void setRmflrnum(int rmflrnum) {
		this.rmflrnum = rmflrnum;
	}
	public int getRm_id() {
		return rm_id;
	}
	public void setRm_id(int rm_id) {
		this.rm_id = rm_id;
	}
	public int getRmtotbd() {
		return rmtotbd;
	}
	public void setRmtotbd(int rmtotbd) {
		this.rmtotbd = rmtotbd;
	}
	public String getRmblknam() {
		return rmblknam;
	}
	public void setRmblknam(String rmblknam) {
		this.rmblknam = rmblknam;
	}
	public String getRmstat() {
		return rmstat;
	}
	public void setRmstat(String rmstat) {
		this.rmstat = rmstat;
	}
	public String getRmnum() {
		return rmnum;
	}
	public void setRmnum(String rmnum) {
		this.rmnum = rmnum;
	}
	
	
	
}
