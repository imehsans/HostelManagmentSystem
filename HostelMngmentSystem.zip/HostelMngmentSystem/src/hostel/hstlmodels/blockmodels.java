package hostel.hstlmodels;

public class blockmodels {
	
	
	int blkId,blkNum,flag; 	//integer type 
	
	String blkNam,blkStat;// string type
	
	
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public int getBlkId() {
		return blkId;
	}
	public void setBlkId(int blkId) {
		this.blkId = blkId;
	}
	public int getBlkNum() {
		return blkNum;
	}
	public void setBlkNum(int blkNum) {
		this.blkNum = blkNum;
	}
	public String getBlkNam() {
		return blkNam;
	}
	public void setBlkNam(String blkNam) {
		this.blkNam = blkNam;
	}
	public String getBlkStat() {
		return blkStat;
	}
	public void setBlkStat(String blkStat) {
		this.blkStat = blkStat;
	}
}
