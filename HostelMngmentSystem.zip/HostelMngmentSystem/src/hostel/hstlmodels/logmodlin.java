package hostel.hstlmodels;

public class logmodlin {
	String unam,passwd,stat;
	int id;
	
	public String getUnam() {
		return unam;
	}
	public void setUnam(String unam) {
		this.unam = unam;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getStat() {
		return stat;
	}
	public void setStat(String stat) {
		this.stat = stat;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
}
