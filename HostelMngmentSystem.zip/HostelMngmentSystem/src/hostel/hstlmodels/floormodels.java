package hostel.hstlmodels;

public class floormodels {
				/////////////declaration 
	String blknam,flrnam,flrstat;
	int flrnum,flrid,flag;
	///////////////////////////////getters and setters
	public String getBlknam() {
		return blknam;
	}
	public void setBlknam(String blknam) {
		this.blknam = blknam;
	}
	public String getFlrnam() {
		return flrnam;
	}
	public void setFlrnam(String flrnam) {
		this.flrnam = flrnam;
	}
	public String getFlrstat() {
		return flrstat;
	}
	public void setFlrstat(String flrstat) {
		this.flrstat = flrstat;
	}
	public int getFlrnum() {
		return flrnum;
	}
	public void setFlrnum(int flrnum) {
		this.flrnum = flrnum;
	}
	public int getFlrid() {
		return flrid;
	}
	public void setFlrid(int flrid) {
		this.flrid = flrid;
	}
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	
}
