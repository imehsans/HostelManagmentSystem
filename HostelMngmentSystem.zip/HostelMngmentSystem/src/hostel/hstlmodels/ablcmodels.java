package hostel.hstlmodels;

public class ablcmodels {
////----------------------------------------------------
	Long ablcTot,ablcOthexp,ablcrmRent,ablcMesfe,ablcSlno;
	int ablcFlg,ablcstdId;
	String ablcRmnum,ablcBlknam,ablcFlornum,ablcStudNam,ablcMonth,ablcyear;
	///==========================
	
	
	public String getAblcyear() {
		return ablcyear;
	}

	public void setAblcyear(String ablcyear) {
		this.ablcyear = ablcyear;
	}

	public String getAblcBlknam() {
		return ablcBlknam;
	}
	 
	public String getAblcMonth() {
		return ablcMonth;
	}
	public void setAblcMonth(String ablcMonth) {
		this.ablcMonth = ablcMonth;
	}
	public void setAblcBlknam(String ablcBlknam) {
		this.ablcBlknam = ablcBlknam;
	}
	public String getAblcFlornum() {
		return ablcFlornum;
	}
	public void setAblcFlornum(String ablcFlornum) {
		this.ablcFlornum = ablcFlornum;
	}
	public String getAblcStudNam() {
		return ablcStudNam;
	}
	public void setAblcStudNam(String ablcStudNam) {
		this.ablcStudNam = ablcStudNam;
	}
	
	public Long getAblcTot() {
		return ablcTot;
	}
	public void setAblcTot(Long ablcTot) {
		this.ablcTot = ablcTot;
	}
	public Long getAblcOthexp() {
		return ablcOthexp;
	}
	public void setAblcOthexp(Long ablcOthexp) {
		this.ablcOthexp = ablcOthexp;
	}
	public Long getAblcrmRent() {
		return ablcrmRent;
	}
	public void setAblcrmRent(Long ablcrmRent) {
		this.ablcrmRent = ablcrmRent;
	}
	public Long getAblcMesfe() {
		return ablcMesfe;
	}
	public void setAblcMesfe(Long ablcMesfe) {
		this.ablcMesfe = ablcMesfe;
	}
	public Long getAblcSlno() {
		return ablcSlno;
	}
	public void setAblcSlno(Long ablcSlno) {
		this.ablcSlno = ablcSlno;
	}
	public int getAblcFlg() {
		return ablcFlg;
	}
	public void setAblcFlg(int ablcFlg) {
		this.ablcFlg = ablcFlg;
	}
	public int getAblcstdId() {
		return ablcstdId;
	}
	public void setAblcstdId(int ablcstdId) {
		this.ablcstdId = ablcstdId;
	}
	public String getAblcRmnum() {
		return ablcRmnum;
	}
	public void setAblcRmnum(String ablcRmnum) {
		this.ablcRmnum = ablcRmnum;
	}
	
	
	
}
