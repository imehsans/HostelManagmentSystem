package hostel.hstlmodels;

public class studentmodels {
	//==============declarations
	int stdId,stdfflag;
	Long studPh,parPh;
	
	String studNam,studAddr,studGend,studEml,parEml,studStat,parntname,stdDob;
	//--------------------
	
	
	public String getStdDob() {
		return stdDob;
	}
	public void setStdDob(String stdDob) {
		this.stdDob = stdDob;
	}
	public String getParntname() {
		return parntname;
	}
	public void setParntname(String parntname) {
		this.parntname = parntname;
	}
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	public int getStdfflag() {
		return stdfflag;
	}
	public void setStdfflag(int stdfflag) {
		this.stdfflag = stdfflag;
	}
	public Long getStudPh() {
		return studPh;
	}
	public void setStudPh(Long studPh) {
		this.studPh = studPh;
	}
	public Long getParPh() {
		return parPh;
	}
	public void setParPh(Long parPh) {
		this.parPh = parPh;
	}
	public String getStudNam() {
		return studNam;
	}
	public void setStudNam(String studNam) {
		this.studNam = studNam;
	}
	public String getStudAddr() {
		return studAddr;
	}
	public void setStudAddr(String studAddr) {
		this.studAddr = studAddr;
	}
	public String getStudGend() {
		return studGend;
	}
	public void setStudGend(String studGend) {
		this.studGend = studGend;
	}
	public String getStudEml() {
		return studEml;
	}
	public void setStudEml(String studEml) {
		this.studEml = studEml;
	}
	public String getParEml() {
		return parEml;
	}
	public void setParEml(String parEml) {
		this.parEml = parEml;
	}
	public String getStudStat() {
		return studStat;
	}
	public void setStudStat(String studStat) {
		this.studStat = studStat;
	}

}
