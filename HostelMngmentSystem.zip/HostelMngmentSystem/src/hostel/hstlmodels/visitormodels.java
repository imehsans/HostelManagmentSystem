package hostel.hstlmodels;

public class visitormodels {
	//==================declarations
	int vstflag,vstslno;
	long vstph;
	String vstnam,vstudnam,vstrelat,vstdate,vstEtme,vstLtme,vstpurp;
	//===========
	
	public int getVstflag() {
		return vstflag;
	}
	public void setVstflag(int vstflag) {
		this.vstflag = vstflag;
	}
	public int getVstslno() {
		return vstslno;
	}
	public void setVstslno(int vstslno) {
		this.vstslno = vstslno;
	}
	public long getVstph() {
		return vstph;
	}
	public void setVstph(long vstph) {
		this.vstph = vstph;
	}
	public String getVstnam() {
		return vstnam;
	}
	public void setVstnam(String vstnam) {
		this.vstnam = vstnam;
	}
	public String getVstudnam() {
		return vstudnam;
	}
	public void setVstudnam(String vstudnam) {
		this.vstudnam = vstudnam;
	}
	public String getVstrelat() {
		return vstrelat;
	}
	public void setVstrelat(String vstrelat) {
		this.vstrelat = vstrelat;
	}
	public String getVstdate() {
		return vstdate;
	}
	public void setVstdate(String vstdate) {
		this.vstdate = vstdate;
	}
	public String getVstEtme() {
		return vstEtme;
	}
	public void setVstEtme(String vstEtme) {
		this.vstEtme = vstEtme;
	}
	public String getVstLtme() {
		return vstLtme;
	}
	public void setVstLtme(String vstLtme) {
		this.vstLtme = vstLtme;
	}
	public String getVstpurp() {
		return vstpurp;
	}
	public void setVstpurp(String vstpurp) {
		this.vstpurp = vstpurp;
	}
	

}
