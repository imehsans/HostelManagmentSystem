package hostel.hstlmodels;


public class grandmodels {
///======================================================
	int grndId,grndFlag,grndstudId;
	Long grndRmrent;
	String grndBlkname,grndFlornum,grndRoomnum,grndStat,grndstudNam,grndprntNam,grndStudStat,grndBlkStat,grndFlrStat,grndRmStat,grndRmTotb;
	//======================================================
	
	public String getGrndFlornum() {
		return grndFlornum;
	}
	public String getGrndStudStat() {
		return grndStudStat;
	}
	public void setGrndStudStat(String grndStudStat) {
		this.grndStudStat = grndStudStat;
	}
	public String getGrndBlkStat() {
		return grndBlkStat;
	}
	public void setGrndBlkStat(String grndBlkStat) {
		this.grndBlkStat = grndBlkStat;
	}
	public String getGrndFlrStat() {
		return grndFlrStat;
	}
	public void setGrndFlrStat(String grndFlrStat) {
		this.grndFlrStat = grndFlrStat;
	}
	public String getGrndRmStat() {
		return grndRmStat;
	}
	public void setGrndRmStat(String grndRmStat) {
		this.grndRmStat = grndRmStat;
	}
	public String getGrndRmTotb() {
		return grndRmTotb;
	}
	public void setGrndRmTotb(String grndRmTotb) {
		this.grndRmTotb = grndRmTotb;
	}
	public void setGrndFlornum(String grndFlornum) {
		this.grndFlornum = grndFlornum;
	}
	public String getGrndstudNam() {
		return grndstudNam;
	}
	public void setGrndstudNam(String grndstudNam) {
		this.grndstudNam = grndstudNam;
	}
	public String getGrndprntNam() {
		return grndprntNam;
	}
	public void setGrndprntNam(String grndprntNam) {
		this.grndprntNam = grndprntNam;
	}
	
	public int getGrndId() {
		return grndId;
	}
	public void setGrndId(int grndId) {
		this.grndId = grndId;
	}
	public int getGrndFlg() {
		return grndFlag;
	}
	public void setGrndFlg(int grndFlag) {
		this.grndFlag = grndFlag;
	}
	public int getGrndstudId() {
		return grndstudId;
	}
	public void setGrndstudId(int grndstudId) {
		this.grndstudId = grndstudId;
	}
	public Long getGrndRmrent() {
		return grndRmrent;
	}
	public void setGrndRmrent(Long grndRmrent) {
		this.grndRmrent = grndRmrent;
	}
	public String getGrndBlkname() {
		return grndBlkname;
	}
	public void setGrndBlkname(String grndBlkname) {
		this.grndBlkname = grndBlkname;
	}
	
	public String getGrndRoomnum() {
		return grndRoomnum;
	}
	public void setGrndRoomnum(String grndRoomnum) {
		this.grndRoomnum = grndRoomnum;
	}
	public String getGrndStat() {
		return grndStat;
	}
	public void setGrndStat(String grndStat) {
		this.grndStat = grndStat;
	}

}
